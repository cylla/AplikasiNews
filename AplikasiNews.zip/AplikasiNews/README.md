# AplikasiNews

Aplikasi berita di indonesia menggunakan API dari https://newsapi.org/
